def main():
    print("Hello from sudoku!")


if __name__ == "__main__":
    main()
